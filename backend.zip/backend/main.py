# backend/main.py

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import requests
from backend.llm import IssueAnalyzer

app = FastAPI(title="GitHub Issue AI Assistant")

analyzer = IssueAnalyzer()

# ---------- REQUEST SCHEMA ----------
class AnalyzeRequest(BaseModel):
    repo_url: str
    issue_number: int


# ---------- ANALYZE ENDPOINT ----------
@app.post("/analyze")
def analyze_issue(payload: AnalyzeRequest):
    try:
        parts = payload.repo_url.rstrip("/").split("/")
        owner, repo = parts[-2], parts[-1]

        issue_url = f"https://api.github.com/repos/{owner}/{repo}/issues/{payload.issue_number}"
        response = requests.get(issue_url)

        if response.status_code != 200:
            raise HTTPException(status_code=404, detail="GitHub issue not found")

        issue = response.json()
        title = issue.get("title", "")
        body = issue.get("body", "")

        result = analyzer.analyze(title, body)
        return result

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

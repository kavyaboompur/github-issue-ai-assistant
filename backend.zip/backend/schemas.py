from pydantic import BaseModel

class IssueRequest(BaseModel):
    repo_url: str
    issue_number: int

import requests

def parse_repo_url(repo_url: str):
    parts = repo_url.rstrip("/").split("/")
    return parts[-2], parts[-1]

def fetch_issue(owner: str, repo: str, issue_number: int) -> str:
    issue_url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
    comments_url = issue_url + "/comments"

    issue_res = requests.get(issue_url)
    comments_res = requests.get(comments_url)

    issue_res.raise_for_status()
    comments_res.raise_for_status()

    issue = issue_res.json()
    comments = comments_res.json()

    text = f"Title: {issue['title']}\n\n"
    text += issue.get("body", "") + "\n\n"

    if comments:
        text += "Comments:\n"
        for c in comments[:5]:
            text += f"- {c.get('body','')}\n"

    return text

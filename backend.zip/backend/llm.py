import os
from transformers import pipeline
import re
# Optional: HuggingFace cache
os.environ["HF_HOME"] = r"D:\huggingface_cache"



# # backend/llm.py



class IssueAnalyzer:
    def analyze(self, title: str, body: str) -> dict:
        text = f"{title} {body}".lower()

        # -----------------------------
        # ISSUE CLASSIFICATION
        # -----------------------------
        if any(k in text for k in ["bug", "error", "crash", "fails", "failure", "exception"]):
            issue_type = "bug"
            priority = "5/5 — critical issue impacting functionality."
            impact = "Users may experience broken functionality."
            labels = ["bug", "backend", "needs-triage"]

        elif any(k in text for k in ["feature", "enhancement", "request", "support"]):
            issue_type = "feature_request"
            priority = "3/5 — improvement"
            impact = "Adds or improves functionality."
            labels = ["feature_request", "enhancement"]

        elif any(k in text for k in ["documentation", "docs", "readme"]):
            issue_type = "documentation"
            priority = "2/5 — documentation issue"
            impact = "Users may be confused due to unclear documentation."
            labels = ["documentation"]

        elif any(k in text for k in ["how", "why", "what", "is it possible"]):
            issue_type = "question"
            priority = "1/5 — informational"
            impact = "No direct impact on users."
            labels = ["question"]

        else:
            issue_type = "other"
            priority = "3/5 — needs triage"
            impact = "Impact is unclear and requires further investigation."
            labels = ["needs-triage"]

        # -----------------------------
        # SUMMARY CLEANING + ENFORCEMENT
        # -----------------------------
        raw = title.strip()

        # Remove markdown / noise
        raw = re.sub(r"\[.*?\]", "", raw)
        raw = re.sub(r"\s+", " ", raw)

        words = raw.split()

        # If summary is broken or too short → fallback sentence
        if len(words) < 10 or raw.endswith(("with", "and", "but", "to")):
            summary = (
                f"This issue reports a {issue_type.replace('_', ' ')} "
                f"related problem that affects functionality and requires attention."
            )
        else:
            summary = " ".join(words[:20]).rstrip(".,") + "."

        return {
            "summary": summary,
            "type": issue_type,
            "priority_score": priority,
            "suggested_labels": labels[:3],
            "potential_impact": impact
        }

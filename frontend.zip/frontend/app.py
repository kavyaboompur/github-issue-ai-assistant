import streamlit as st
import requests
import json

# -----------------------------
# Page Config
# -----------------------------
st.set_page_config(
    page_title="GitHub Issue AI Assistant",
    page_icon="🐙",
    layout="wide"
)

# -----------------------------
# Custom CSS
# -----------------------------
st.markdown(
    """
    <style>
        .stApp {
            background-color: #f2f2f2;
        }
        .center {
            text-align: center;
        }
    </style>
    """,
    unsafe_allow_html=True
)

# -----------------------------
# Session State
# -----------------------------
if "page" not in st.session_state:
    st.session_state.page = "home"

if "analysis" not in st.session_state:
    st.session_state.analysis = None

if "preview" not in st.session_state:
    st.session_state.preview = None

if "show_json" not in st.session_state:
    st.session_state.show_json = False

# =====================================================
# HOME / LANDING PAGE
# =====================================================
if st.session_state.page == "home":

    st.markdown(
        """
        <div class="center" style="margin-top:150px;">
            <h1>🐙 GitHub Issue AI Assistant</h1>
            <p style="font-size:18px; max-width:700px; margin:0 auto;">
                An AI-powered tool that analyzes GitHub issues and generates structured
                insights such as issue type, priority, labels, and potential impact.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    st.markdown("<br><br>", unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("🚀 Start", use_container_width=True):
            st.session_state.page = "analyze"

# =====================================================
# ANALYZE PAGE
# =====================================================
if st.session_state.page == "analyze":

    st.title("🔧 Analyze GitHub Issue")

    # -----------------------------
    # Inputs
    # -----------------------------
    repo_url = st.text_input(
        "GitHub Repository URL",
        placeholder="https://github.com/owner/repository"
    )

    issue_number = st.number_input(
        "Issue Number",
        min_value=1,
        step=1
    )

    st.markdown("### Actions")
    col1, col2, col3, col4 = st.columns(4)

    # -----------------------------
    # Analyze Issue
    # -----------------------------
    with col1:
        if st.button("🧠 Analyze Issue"):
            if repo_url and issue_number:
                with st.spinner("Analyzing issue..."):
                    try:
                        res = requests.post(
                            "http://127.0.0.1:8000/analyze",
                            json={
                                "repo_url": repo_url,
                                "issue_number": issue_number
                            },
                            timeout=60
                        )
                        res.raise_for_status()
                        st.session_state.analysis = res.json()
                        st.session_state.show_json = False
                        st.success("Analysis complete.")
                    except Exception as e:
                        st.error(f"Backend error: {e}")
            else:
                st.warning("Please enter repository URL and issue number.")

    # -----------------------------
    # Preview Issue
    # -----------------------------
    with col2:
        if st.button("👀 Preview Issue"):
            try:
                parts = repo_url.rstrip("/").split("/")
                owner, repo = parts[-2], parts[-1]

                issue_res = requests.get(
                    f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
                )

                if issue_res.status_code == 200:
                    st.session_state.preview = issue_res.json()
                else:
                    st.error("Unable to fetch issue preview")
            except Exception:
                st.error("Invalid repository URL")

    # -----------------------------
    # View Result (JSON)
    # -----------------------------
    with col3:
        if st.button("📄 View Result"):
            if st.session_state.analysis:
                st.session_state.show_json = True
            else:
                st.warning("Analyze an issue first.")

    # -----------------------------
    # Download JSON
    # -----------------------------
    with col4:
        if st.session_state.analysis:
            st.download_button(
                "⬇ Download JSON",
                data=json.dumps(st.session_state.analysis, indent=2),
                file_name=f"github_issue_{issue_number}_analysis.json",
                mime="application/json"
            )

    st.divider()

    # -----------------------------
    # View JSON Result (RAW JSON WITH COMMAS)
    # -----------------------------
    if st.session_state.show_json and st.session_state.analysis:
        st.subheader("📄 View JSON Result")
        st.code(
            json.dumps(st.session_state.analysis, indent=2),
            language="json"
        )

    # -----------------------------
    # Readable Summary
    # -----------------------------
    if st.session_state.analysis:
        data = st.session_state.analysis

        st.subheader("📝 Readable Summary")
        st.write("**Summary:**")
        st.write(data["summary"])

        st.write("**Issue Type:**", data["type"])
        st.write("**Priority Score:**", data["priority_score"])
        st.write("**Suggested Labels:**", ", ".join(data["suggested_labels"]))
        st.write("**Potential Impact:**", data["potential_impact"])

    # -----------------------------
    # Preview Output
    # -----------------------------
    if st.session_state.preview:
        issue = st.session_state.preview

        st.subheader("👁 Issue Preview")
        st.markdown(f"**Title:** {issue.get('title', '')}")
        st.markdown("**Description:**")
        st.write(issue.get("body", "No description available"))
